import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-personal',
  standalone: true,
  templateUrl: './personal.component.html',
  styleUrls: ['./personal.component.css'],
  imports: [CommonModule, FormsModule]
})
export class PersonalComponent {
  personal: any[] = [];
  id = '';
  nombre = '';
  categoria = 'Maestro';
  salario: number | null = null;
  editando = false;
  busqueda = '';
  personaEditando: any = null;

  // Validaciones
  nombreInvalido = false;
  salarioInvalido = false;
  nombreMensaje = '';

  constructor(private router: Router) {}

  irA(ruta: string) {
    this.router.navigate([ruta]);
  }

  cerrarSesion() {
    this.router.navigate(['']);
  }

  generarId(): string {
    return 'PERS-' + Math.floor(1000 + Math.random() * 9000); // PERS-1234
  }

  validarDatos(): boolean {
    const soloLetrasRegex = /^[a-zA-ZÁÉÍÓÚÑáéíóúñ\s]+$/;

    this.nombreInvalido = !this.nombre.trim() ||
      this.nombre.trim().length < 3 ||
      this.nombre.trim().length > 50 ||
      !soloLetrasRegex.test(this.nombre.trim());

    this.salarioInvalido = this.salario === null || this.salario <= 0;

    if (this.nombreInvalido) {
      if (!this.nombre.trim()) this.nombreMensaje = 'El nombre es obligatorio.';
      else if (this.nombre.length < 3) this.nombreMensaje = 'Debe tener al menos 3 letras.';
      else if (this.nombre.length > 50) this.nombreMensaje = 'No debe superar 50 caracteres.';
      else this.nombreMensaje = 'Solo letras y espacios son permitidos.';
    }

    return !(this.nombreInvalido || this.salarioInvalido);
  }

  agregarPersonal() {
    if (!this.validarDatos()) return;

    if (this.editando && this.personaEditando) {
      this.personaEditando.nombre = this.nombre.trim();
      this.personaEditando.salario = this.salario;
      this.cancelarEdicion();
    } else {
      const nuevoPersonal = {
        id: this.generarId(),
        nombre: this.nombre.trim(),
        categoria: 'Maestro',
        salario: this.salario
      };
      this.personal.push(nuevoPersonal);
      this.limpiarCampos();
    }
  }

  editarPersonal(persona: any) {
    this.editando = true;
    this.personaEditando = persona;
    this.id = persona.id;
    this.nombre = persona.nombre;
    this.salario = persona.salario;

    this.nombreInvalido = false;
    this.salarioInvalido = false;
  }

  eliminarPersonal(persona: any) {
    this.personal = this.personal.filter(p => p !== persona);
  }

  cancelarEdicion() {
    this.editando = false;
    this.personaEditando = null;
    this.limpiarCampos();
  }

  limpiarCampos() {
    this.id = '';
    this.nombre = '';
    this.categoria = 'Maestro';
    this.salario = null;

    this.nombreInvalido = false;
    this.salarioInvalido = false;
  }
}
