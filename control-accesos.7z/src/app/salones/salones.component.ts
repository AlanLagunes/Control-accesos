import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-salones',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './salones.component.html',
  styleUrls: ['./salones.component.css']
})
export class SalonesComponent {
  salonActivo: number | null = null;

  alumnos = [
    { nombre: 'Juan Pérez' },
    { nombre: 'Ana Torres' }
  ];

  personal = [
    { nombre: 'Luis Méndez', categoria: 'Profesor' },
    { nombre: 'Claudia Rivas', categoria: 'Administración' }
  ];

  abrirSalon(numero: number) {
    this.salonActivo = this.salonActivo === numero ? null : numero;
  }
}
