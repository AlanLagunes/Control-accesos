import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  loginForm: FormGroup;
  twoFaForm: FormGroup;
  cambiarContrasenaForm: FormGroup;
  mostrar2fa = false;
  errorLogin = '';
  error2fa = '';
  codigo2faFijo = '123456';

  alumnoLogueado: any = null;
  esAdmin = false;
  logueado = false;

  mensaje = '';

  constructor(private fb: FormBuilder, private router: Router) {
    this.loginForm = this.fb.group({
      username: ['', [Validators.required, Validators.maxLength(20)]],
      password: ['', [Validators.required, Validators.maxLength(8)]],
    });

    this.twoFaForm = this.fb.group({
      codigo2fa: ['', [Validators.required, Validators.maxLength(6), Validators.minLength(6)]]
    });

    this.cambiarContrasenaForm = this.fb.group({
      nuevaContrasena: ['', [Validators.required, Validators.minLength(3)]]
    });
  }

  login() {
    this.errorLogin = '';
    if (this.loginForm.invalid) {
      this.errorLogin = 'Por favor completa todos los campos correctamente';
      return;
    }

    const { username, password } = this.loginForm.value;

    if (username === 'admin' && password === 'admin') {
      this.alumnoLogueado = null;
      this.esAdmin = true;
      this.mostrar2fa = true;
      this.error2fa = '';
      this.twoFaForm.reset();
      return;
    }

    const alumnosStr = localStorage.getItem('alumnos');
    if (!alumnosStr) {
      this.errorLogin = 'No hay alumnos registrados';
      return;
    }

    const alumnos = JSON.parse(alumnosStr);
    const alumnoEncontrado = alumnos.find(
      (a: any) => a.nombre.toLowerCase() === username.toLowerCase() && a.contrasena === password
    );

    if (!alumnoEncontrado) {
      this.errorLogin = 'Usuario o contraseña incorrectos';
      return;
    }

    this.alumnoLogueado = alumnoEncontrado;
    this.esAdmin = false;
    this.mostrar2fa = true;
    this.error2fa = '';
    this.twoFaForm.reset();
  }

  verificarCodigo2fa() {
    this.error2fa = '';
    if (this.twoFaForm.invalid) {
      this.error2fa = 'Código 2FA inválido';
      return;
    }

    const codigoIngresado = this.twoFaForm.value.codigo2fa;

    if (codigoIngresado === this.codigo2faFijo) {
      if (this.esAdmin) {
        this.router.navigate(['/inicio']);
      } else {
        this.logueado = true;
        this.mostrar2fa = false;
        this.cambiarContrasenaForm.reset();
        this.mensaje = '';
      }
    } else {
      this.error2fa = 'Código 2FA incorrecto';
    }
  }

  guardarContrasena() {
    this.mensaje = '';
    if (this.cambiarContrasenaForm.invalid) {
      this.mensaje = 'La nueva contraseña no puede estar vacía y debe tener al menos 3 caracteres.';
      return;
    }

    const nuevaContrasena = this.cambiarContrasenaForm.value.nuevaContrasena.trim();

    this.alumnoLogueado.contrasena = nuevaContrasena;

    const alumnosStr = localStorage.getItem('alumnos');
    if (!alumnosStr) return;

    const alumnos = JSON.parse(alumnosStr);
    const index = alumnos.findIndex((a: any) => a.id === this.alumnoLogueado.id);

    if (index !== -1) {
      alumnos[index].contrasena = nuevaContrasena;
      localStorage.setItem('alumnos', JSON.stringify(alumnos));
      this.mensaje = 'Contraseña actualizada correctamente.';
      this.cambiarContrasenaForm.reset();
    } else {
      this.mensaje = 'Error: no se encontró el alumno para actualizar.';
    }
  }

  cerrarSesion() {
    this.logueado = false;
    this.alumnoLogueado = null;
    this.esAdmin = false;
    this.loginForm.reset();
    this.twoFaForm.reset();
    this.cambiarContrasenaForm.reset();
    this.mostrar2fa = false;
    this.errorLogin = '';
    this.error2fa = '';
    this.mensaje = '';
  }
}
