import { Component } from '@angular/core';

@Component({
  selector: 'app-correo',
  imports: [],
  templateUrl: './correo.component.html',
  styleUrl: './correo.component.css'
})
export class CorreoComponent {

}
