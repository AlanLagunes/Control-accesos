import { Component } from '@angular/core';

@Component({
  selector: 'app-opciones',
  imports: [],
  templateUrl: './opciones.component.html',
  styleUrl: './opciones.component.css'
})
export class OpcionesComponent {

}
