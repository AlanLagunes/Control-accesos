import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-perfil-alumno',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './perfil-alumno.component.html',
  styleUrls: ['./perfil-alumno.component.css']
})
export class PerfilAlumnoComponent {
  alumno: any = null;
  nuevaContrasena = '';
  mensaje = '';

  constructor(private router: Router) {
    const alumnoStr = localStorage.getItem('alumnoLogueado');
    if (alumnoStr) {
      this.alumno = JSON.parse(alumnoStr);
    } else {
      this.router.navigate(['/login']);
    }
  }

  guardarContrasena() {
    if (!this.nuevaContrasena.trim()) {
      this.mensaje = 'La nueva contraseña no puede estar vacía.';
      return;
    }

    this.alumno.contrasena = this.nuevaContrasena.trim();

    const alumnosStr = localStorage.getItem('alumnos');
    if (!alumnosStr) return;

    const alumnos = JSON.parse(alumnosStr);
    const index = alumnos.findIndex((a: any) => a.id === this.alumno.id);

    if (index !== -1) {
      alumnos[index].contrasena = this.alumno.contrasena;
      localStorage.setItem('alumnos', JSON.stringify(alumnos));
      localStorage.setItem('alumnoLogueado', JSON.stringify(this.alumno));
      this.mensaje = 'Contraseña actualizada correctamente.';
      this.nuevaContrasena = '';
    } else {
      this.mensaje = 'Error: no se encontró el alumno para actualizar.';
    }
  }

  cerrarSesion() {
    localStorage.removeItem('alumnoLogueado');
    this.router.navigate(['/login']);
  }
}

