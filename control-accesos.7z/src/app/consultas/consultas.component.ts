import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-consultas',
  standalone: true,
  templateUrl: './consultas.component.html',
  styleUrls: ['./consultas.component.css'],
  imports: [CommonModule]
})
export class ConsultasComponent {
  alumnos = [
    {
      id: 'A001',
      nombre: 'Juan Pérez',
      matricula: '12345',
      carrera: 'Ingeniería',
      correo: 'juan@mail.com',
      salon: 'Salon 1'
    },
    {
      id: 'A002',
      nombre: 'Ana López',
      matricula: '12346',
      carrera: 'Arquitectura',
      correo: 'ana@mail.com',
      salon: 'Salon 2'
    }
  ];

  personal = [
    {
      id: 'P001',
      nombre: 'Carlos Ruiz',
      categoria: 'Docente',
      salario: '12000',
      correo: 'carlos@mail.com',
      salon: 'Salon 1'
    },
    {
      id: 'P002',
      nombre: 'Marta Gómez',
      categoria: 'Administrativo',
      salario: '10000',
      correo: 'marta@mail.com',
      salon: 'Salon 3'
    }
  ];

  salones = [
    {
      nombre: 'Salon 1',
      capacidad: 30,
      personas: ['Juan Pérez', 'Carlos Ruiz']
    },
    {
      nombre: 'Salon 2',
      capacidad: 25,
      personas: ['Ana López']
    },
    {
      nombre: 'Salon 3',
      capacidad: 35,
      personas: ['Marta Gómez']
    }
  ];

  constructor(private router: Router) {}

  irA(ruta: string) {
    this.router.navigate(['/' + ruta]);
  }
}
