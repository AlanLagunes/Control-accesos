import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./login/login.component').then(m => m.LoginComponent)
  },
  {
    path: 'inicio',
    loadComponent: () => import('./inicio/inicio.component').then(m => m.InicioComponent)
  },
  {
    path: 'opciones',
    loadComponent: () => import('./opciones/opciones.component').then(m => m.OpcionesComponent)
  },
  {
    path: 'consultas',
    loadComponent: () => import('./consultas/consultas.component').then(m => m.ConsultasComponent)
  },
  {
    path: 'correo',
    loadComponent: () => import('./correo/correo.component').then(m => m.CorreoComponent)
  },
  {
    path: 'alumnos',
    loadComponent: () => import('./alumnos/alumnos.component').then(m => m.GestionAlumnosComponent)
  },
  {
    path: 'personal',
    loadComponent: () => import('./personal/personal.component').then(m => m.PersonalComponent)
  },
  {
    path: 'salones',
    loadComponent: () => import('./salones/salones.component').then(m => m.SalonesComponent)
  },
  { path: '**', redirectTo: '' }
];
