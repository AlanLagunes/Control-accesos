import { Component } from '@angular/core';

@Component({
  selector: 'app-principal',
  standalone: true,        // Agregado para componente standalone
  templateUrl: './principal.component.html',
  styleUrls: ['./principal.component.css']  // Corregido aquí: styleUrls en plural
})
export class PrincipalComponent {
  // Lógica del componente aquí (vacío por ahora)
}
