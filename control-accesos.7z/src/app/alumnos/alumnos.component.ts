import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-gestion-alumnos',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './alumnos.component.html',
  styleUrls: ['./alumnos.component.css']
})
export class GestionAlumnosComponent implements OnInit {
  busqueda: string = '';
  id: string = '';
  nombre: string = '';
  matricula: string = '';
  carrera: string = '';
  correo: string = '';
  salon: string = '';
  contrasenaTemporal: string = '';
  mostrarContrasenaTemporal: boolean = false;
  editando: boolean = false;
  indiceEditando: number = -1;

  alumnos: any[] = [];

  // Variables de validación
  nombreInvalido = false;
  correoInvalido = false;
  carreraInvalida = false;
  carreraMensaje = '';
  salonInvalido = false;

  ngOnInit() {
    this.cargarAlumnos();
  }

  cargarAlumnos() {
    const data = localStorage.getItem('alumnos');
    if (data) {
      this.alumnos = JSON.parse(data);
    }
  }

  guardarAlumnos() {
    localStorage.setItem('alumnos', JSON.stringify(this.alumnos));
  }

  get alumnosFiltrados() {
    return this.alumnos.filter(alumno =>
      alumno.nombre.toLowerCase().includes(this.busqueda.toLowerCase()) ||
      alumno.id.toLowerCase().includes(this.busqueda.toLowerCase())
    );
  }

  validarDatos() {
    const nombreRegex = /^[A-Za-zÁÉÍÓÚáéíóúÑñ\s]{1,50}$/;
    this.nombreInvalido = !this.nombre.trim() || !nombreRegex.test(this.nombre.trim());

    const correoValido = /^\S+@\S+\.\S+$/.test(this.correo.trim());
    this.correoInvalido = !this.correo.trim() || !correoValido;

    const carreraRegex = /^[A-Za-zÁÉÍÓÚáéíóúÑñ\s]{3,50}$/;
    this.carreraInvalida = !this.carrera.trim() || !carreraRegex.test(this.carrera.trim());

    if (!this.carrera.trim()) {
      this.carreraMensaje = 'La carrera es obligatoria.';
    } else if (this.carrera.trim().length < 3) {
      this.carreraMensaje = 'La carrera debe tener al menos 3 caracteres.';
    } else if (this.carrera.trim().length > 50) {
      this.carreraMensaje = 'La carrera no puede exceder los 50 caracteres.';
    } else if (!carreraRegex.test(this.carrera.trim())) {
      this.carreraMensaje = 'Solo se permiten letras y espacios.';
    } else {
      this.carreraMensaje = '';
    }

    this.salonInvalido = !this.salon.trim();

    return !(this.nombreInvalido || this.correoInvalido || this.carreraInvalida || this.salonInvalido);
  }

  generarId() {
    return 'ALU' + Date.now().toString().slice(-6) + Math.floor(Math.random() * 1000);
  }

  generarMatricula() {
    const nextNumber = this.alumnos.length + 1;
    return 'MAT' + nextNumber.toString().padStart(5, '0');
  }

  generarContrasenaTemporal(length: number = 8): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let pass = '';
    for (let i = 0; i < length; i++) {
      pass += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return pass;
  }

  agregarAlumno() {
    if (!this.validarDatos()) return;

    if (!this.editando) {
      this.contrasenaTemporal = this.generarContrasenaTemporal();
      this.mostrarContrasenaTemporal = true;

      const nuevoAlumno = {
        id: this.generarId(),
        nombre: this.nombre.trim(),
        matricula: this.generarMatricula(),
        carrera: this.carrera.trim(),
        correo: this.correo.trim(),
        salon: this.salon,
        contrasena: this.contrasenaTemporal
      };

      this.alumnos.push(nuevoAlumno);
      this.guardarAlumnos();

      // Limpiar campos excepto contraseña visible
      this.limpiarCampos(false);

      setTimeout(() => {
        this.mostrarContrasenaTemporal = false;
        this.contrasenaTemporal = '';
      }, 10000);

    } else {
      // Editar alumno existente
      const actualizado = {
        id: this.id,
        nombre: this.nombre.trim(),
        matricula: this.matricula,
        carrera: this.carrera.trim(),
        correo: this.correo.trim(),
        salon: this.salon,
        contrasena: this.alumnos[this.indiceEditando].contrasena
      };

      this.alumnos[this.indiceEditando] = actualizado;
      this.guardarAlumnos();
      this.cancelarEdicion();
    }
  }

  editarAlumno(indice: number) {
    const alumno = this.alumnos[indice];
    this.id = alumno.id;
    this.nombre = alumno.nombre;
    this.matricula = alumno.matricula;
    this.carrera = alumno.carrera;
    this.correo = alumno.correo;
    this.salon = alumno.salon;
    this.contrasenaTemporal = alumno.contrasena;
    this.editando = true;
    this.indiceEditando = indice;

    this.resetValidaciones();
  }

  eliminarAlumno(indice: number) {
    this.alumnos.splice(indice, 1);
    this.guardarAlumnos();
    this.cancelarEdicion();
  }

  cancelarEdicion() {
    this.editando = false;
    this.indiceEditando = -1;
    this.limpiarCampos();
    this.resetValidaciones();
  }

  limpiarCampos(limpiarContrasena: boolean = true) {
    this.id = '';
    this.nombre = '';
    this.matricula = '';
    this.carrera = '';
    this.correo = '';
    this.salon = '';
    if (limpiarContrasena) {
      this.contrasenaTemporal = '';
      this.mostrarContrasenaTemporal = false;
    }
  }

  resetValidaciones() {
    this.nombreInvalido = false;
    this.correoInvalido = false;
    this.carreraInvalida = false;
    this.carreraMensaje = '';
    this.salonInvalido = false;
  }
}
