import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },

  {
    path: 'login',
    loadComponent: () => import('./login/login.component').then(m => m.LoginComponent),
  },
  {
    path: 'inicio',
    loadComponent: () => import('./inicio/inicio.component').then(m => m.InicioComponent),
  },
  {
    path: 'perfil-alumno',
    loadComponent: () =>
      import('./perfil-alumno/perfil-alumno.component').then(m => m.PerfilAlumnoComponent),
  },

  { path: '**', redirectTo: 'login' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
