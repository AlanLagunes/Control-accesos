import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-two-factor',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './two-factor.component.html',
  styleUrls: ['./two-factor.component.css']
})
export class TwoFactorComponent {
  codigoIngresado: string = '';
  codigo2faCorrecto: string = '123456'; // Código fijo, cambia según lógica
  error: string = '';

  constructor(private router: Router) {}

  verificarCodigo() {
    if (this.codigoIngresado.trim() === this.codigo2faCorrecto) {
      // Guardamos flag para indicar que pasó el 2FA
      localStorage.setItem('twoFactorVerified', 'true');

      // Redirigir al inicio o dashboard
      this.router.navigate(['/inicio']);
    } else {
      this.error = 'Código 2FA incorrecto';
    }
  }
}
