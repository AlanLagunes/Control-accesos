import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(private router: Router) {}

  canActivate(): boolean {
    const isAuthenticated = localStorage.getItem('authenticated');
    const user = localStorage.getItem('user');

    if (isAuthenticated === 'true' && user) {
      return true; // Ya pasó el 2FA
    } else if (user && isAuthenticated !== 'true') {
      this.router.navigate(['/2fa']); // Logueado pero pendiente de 2FA
      return false;
    } else {
      this.router.navigate(['/login']); // No logueado
      return false;
    }
  }
}
